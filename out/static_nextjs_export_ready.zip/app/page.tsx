
'use client';

import MemeMaker from '../components/MemeMaker';

export default function Home() {
  return <MemeMaker />;
}
